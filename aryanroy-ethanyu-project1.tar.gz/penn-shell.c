#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

pid_t pid, wpid;
int status = 0;

int countPipes(char *input)
{
    int count = 0;
    while (*input)
    {
        if (*input == '|')
        {
            count++;
        }
        input++;
    }
    return count;
}

int fileExists(char *filename)
{
    int fd = open(filename, O_RDONLY);
    if (fd != -1)
        return 1;
    else
        return 0;
}

int isEmpty(char *input)
{
    while (*input)
    {
        if (*input != ' ' && *input != '\t' && *input != '\n')
        {
            return 0;
        }
        input++;
    }
    return 1;
}

void writePrompt()
{
    write(STDERR_FILENO, PROMPT, strlen(PROMPT));
}

void sighandler(int signal)
{
    if (signal == SIGINT)
    {
        write(STDERR_FILENO, "\n", strlen("\n"));
        writePrompt();
    }
}

char **reallocate(char **input, int numChar)
{
    char **ret = malloc(sizeof(char *) * numChar);
    for (int i = 0; i < numChar - 1; i++)
    {
        ret[i] = input[i];
    }
    free(input);
    return ret;
}

char **getArgs(char *input)
{
    int numArgs = 1;
    char **ret = NULL;
    char *word = strtok(input, "\t ");
    while (word != NULL)
    {
        ret = reallocate(ret, numArgs);
        ret[numArgs++ - 1] = word;
        word = strtok(NULL, "\t ");
    }
    ret = reallocate(ret, numArgs);
    ret[numArgs - 1] = NULL;
    return ret;
}

void execute(char *input, int hasInput, int hasOutput)
{
    char **args = getArgs(input);
    char *input_file = NULL;
    char *output_file = NULL;

    int appendOutput = 0;
    for (int i = 0; args[i]; i++)
    {
        if (strcmp(args[i], "<") == 0)
        {
            if (hasInput)
            {
                perror("Invalid: more than one input redirection into a process.");
                exit(EXIT_FAILURE);
            }
            args[i] = NULL;
            input_file = args[++i];
            int fd = open(input_file, O_RDONLY);
            if (fd == -1)
            {
                perror("Input file doesn't exist.");
                exit(EXIT_FAILURE);
            }
            hasInput = 1;
        }
        else if (strcmp(args[i], ">") == 0)
        {
            if (hasOutput)
            {
                perror("Invalid: more than one output redirection into a process.");
                exit(EXIT_FAILURE);
            }
            args[i] = NULL;
            output_file = args[++i];
            hasOutput = 1;
        }
        else if (strcmp(args[i], ">>") == 0)
        {
            if (hasOutput)
            {
                perror("Invalid: more than one output redirection into a process.");
                exit(EXIT_FAILURE);
            }
            args[i] = NULL;
            output_file = args[++i];
            if (fileExists(output_file))
            {
                appendOutput = 1;
            }
            hasOutput = 1;
        }
    }

    pid = fork();
    if (pid < 0)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }
    if (pid == 0 && strlen(input) != 0)
    {
        if (input_file)
        {
            int fd = open(input_file, O_RDONLY);
            dup2(fd, STDIN_FILENO);
            close(fd);
        }

        if (output_file && appendOutput == 0)
        {
            int fd2;
            if (fileExists(output_file))
            {
                fd2 = open(output_file, O_WRONLY | O_TRUNC);
            }
            else
            {
                fd2 = open(output_file, O_WRONLY | O_CREAT, 0644);
            }

            dup2(fd2, STDOUT_FILENO);
            close(fd2);
        }

        if (output_file && appendOutput == 1)
        {
            int fd2 = open(output_file, O_WRONLY | O_APPEND);
            dup2(fd2, STDOUT_FILENO);
            close(fd2);
        }

        execvp(args[0], args);

        perror("invalid exectuable");
        exit(EXIT_FAILURE);
    }
    else if (pid > 0)
    {
        wait(NULL);
    }
    free(args);
}

int main(int argc, char *argv[])
{
    int interactive = isatty(STDIN_FILENO);
    if (argc != 3 && argc != 1)
    {
        write(STDERR_FILENO, "Invalid number of arguments (only 0 or 2 accepted).\n", strlen("Invalid number of arguments (only 0 or 2 accepted).\n"));
        exit(EXIT_FAILURE);
    }

    signal(SIGINT, sighandler);

    while (1)
    {
        if (interactive)
        {
            writePrompt();
        }

        char input[4096] = "";
        int n = read(STDIN_FILENO, input, sizeof(input) - 1);

        if (n < 0)
        {
            write(STDERR_FILENO, "\n", strlen("\n"));
            exit(EXIT_FAILURE);
        }

        else if (n == 0)
        {
            write(STDERR_FILENO, "\n", strlen("\n"));
            exit(EXIT_SUCCESS);
        }

        else
        {
            if (isEmpty(input))
                continue;
            if (input[n - 1] == '\n')
            {
                input[n - 1] = '\0';
            }
            else
            {
                input[n] = '\0';
            }
        }

        int numPipes = countPipes(input);
        int initialPipes = numPipes;
        int prev_pipe_read = STDIN_FILENO;

        pid_t pgLeader = 0;
        char *command = strtok(input, "|");
        while (command != NULL)
        {
            int pipes[2];
            if (numPipes-- > 0)
            {
                if (pipe(pipes) == -1)
                {
                    perror("pipe");
                    exit(EXIT_FAILURE);
                }
            }

            pid = fork();
            if (pid < 0)
            {
                perror("fork");
                exit(EXIT_FAILURE);
            }

            if (pid == 0)
            {
                if (pgLeader == 0)
                {
                    pgLeader = getpid();
                }
                setpgid(0, pgLeader);
                if (numPipes >= 0)
                {
                    close(pipes[0]); // close reading end, we're going to write to this pipe
                    dup2(pipes[1], STDOUT_FILENO);
                    close(pipes[1]);
                }

                if (prev_pipe_read != STDIN_FILENO)
                {
                    dup2(prev_pipe_read, STDIN_FILENO);
                    close(prev_pipe_read); // close the descriptor after duplicating
                }
                int hasInput = 1;
                int hasOutput = 1;
                if (initialPipes == numPipes + 1) hasInput = 0;
                if (numPipes == -1) hasOutput = 0;
                execute(command, hasInput, hasOutput);
                exit(EXIT_FAILURE);
            }
            else
            {

                if (pgLeader == 0)
                {
                    pgLeader = pid;
                    setpgid(pid, pgLeader);
                }
                else
                {
                    setpgid(pid, pgLeader);
                }
                if (prev_pipe_read != STDIN_FILENO)
                {
                    close(prev_pipe_read);
                }
                if (numPipes >= 0)
                {
                    close(pipes[1]);
                    prev_pipe_read = pipes[0];
                }
                if (numPipes < 0 && prev_pipe_read != STDIN_FILENO)
                {

                    close(prev_pipe_read);
                }
            }

            command = strtok(NULL, "|");
        }

        while (wait(NULL) > 0)
            ;
    }
    return (0);
}
